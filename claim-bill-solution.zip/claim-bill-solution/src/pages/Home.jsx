import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow p-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Claim Bill Solution</h1>
          <a href="/login" className="text-blue-600 hover:underline">Login</a>
        </div>
      </header>
      <main className="p-8 max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold mb-4">Simplifying your medical billing and claims</h2>
        <p className="text-lg mb-6">
          We help you manage, track, and resolve your claims quickly and securely.
        </p>
        <a href="/contact" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700">Get Started</a>
      </main>
      <footer className="bg-white text-center text-sm text-gray-500 py-4 mt-8">
        &copy; 2025 Claim Bill Solution. All rights reserved.
      </footer>
    </div>
  );
}
